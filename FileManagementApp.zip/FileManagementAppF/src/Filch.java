import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;

public class Filch extends SimpleFileVisitor<Path>{

	private Path sourceRootDirectory;
	private Path targetRootDirectory;
	
	
	private Filch(Path sourceRootDirectory, Path targetRootDirectory) {
		this.sourceRootDirectory = sourceRootDirectory;
		this.targetRootDirectory = targetRootDirectory;
	}
	
	public static Filch copyOrReplaceExisting(Path sourceRootDirectory, Path targetRootDirectory) {
		return new Filch(sourceRootDirectory, targetRootDirectory);
	}

	@Override
	public FileVisitResult visitFileFailed(Path file, IOException e) throws IOException {
		System.out.println("Error accessing file: " + file.toAbsolutePath());
		System.out.println("visitFileFailed " + e.getMessage());
		return FileVisitResult.CONTINUE;
	}

	@Override
	public FileVisitResult preVisitDirectory(Path sourceDirectory, BasicFileAttributes attrs) throws IOException {
		
		Path relativizedPath = sourceRootDirectory.relativize(sourceDirectory); //i.e. relativizedPath = SubFolder ;
		Path targetDirectory = targetRootDirectory.resolve(relativizedPath); //i.e. targetDirectory = TargetRootFolder/SubFolder;
		
		try {
			Files.copy(sourceDirectory, targetDirectory, StandardCopyOption.REPLACE_EXISTING);
			System.out.println("Successfully copied " + sourceDirectory.toAbsolutePath() + " to " + targetDirectory.toAbsolutePath());
		}catch(DirectoryNotEmptyException e) {
			System.out.println("preVisitDirectory() :: DirectoryNotEmptyException " + e.getMessage());
		}catch(IOException e) {
			e.printStackTrace();
			System.out.println("preVisitDirectory " + e.getMessage());
			return FileVisitResult.SKIP_SUBTREE;
		}
		
		return FileVisitResult.CONTINUE;
	}

	
	@Override
	public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
		System.out.println("postVisitDirectory");
		System.out.println("--" + dir.toAbsolutePath() + "--");
		return FileVisitResult.CONTINUE;
	}

	@Override
	public FileVisitResult visitFile(Path sourceFile, BasicFileAttributes attrs) throws IOException {
		Path relativizedPath = sourceRootDirectory.relativize(sourceFile); //i.e. relativizedPath = SubFolder/file1.txt; 
		Path targetFile = targetRootDirectory.resolve(relativizedPath); //i.e. targetFile = SubFolder/file1.txt; 
		
		try {
			
			if(Files.deleteIfExists(targetFile)) {
				System.out.println("visitFile successfully deleted: " + targetFile.toAbsolutePath());
			}
			Files.copy(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
			System.out.println("Successfully copied " + sourceFile.toAbsolutePath() + " to " + targetFile.toAbsolutePath());
		}catch(IOException e) {
			System.out.println("visitFile " + e.getMessage());
		}
		
		return FileVisitResult.CONTINUE;
	}

	
	
	
}
