import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class FileManagementApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, String> propertyFile = readPropertyFile();

		if(propertyFile.size() > 0) {
			Path sourceDirectory = FileSystems.getDefault().getPath(propertyFile.get("source"));
			Path targetDirectory = FileSystems.getDefault().getPath(propertyFile.get("target"));

			try {
				Files.walkFileTree(sourceDirectory, Filch.copyOrReplaceExisting(sourceDirectory, targetDirectory));
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	
	private static Map<String, String> readPropertyFile(){
		Map<String, String> propertyMap = new LinkedHashMap<>();

		try (BufferedReader fileToRead = new BufferedReader(new FileReader("file.properties"))) {
			String input;
			while ((input = fileToRead.readLine()) != null) {
				String[] data = input.split(" ");
				propertyMap.put("source", generatePath(data[0]));
				propertyMap.put("target", generatePath(data[1]));
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("readPropertyFile " + propertyMap.size());
		return propertyMap;
	}
	
	private static String generatePath(String rawPath) {
		String[] rawPathArr = rawPath.split("/");
		StringBuffer generatedPath = new StringBuffer();
		for (int i = 0; i < rawPathArr.length; i++) {
			if (i < rawPathArr.length - 1) {
				generatedPath.append(rawPathArr[i]);
				generatedPath.append(File.separator);
			} else {
				generatedPath.append(rawPathArr[i]);
			}
		}
		return generatedPath.toString();
	}
}
